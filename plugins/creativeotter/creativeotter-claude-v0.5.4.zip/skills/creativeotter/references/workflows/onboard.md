> CreativeOtter adaptation, 2026-11-01. [Runtime contract](../runtime-contract.md) governs execution. This inherited creative/technical guide is not a current model catalog, price list, API schema or product-policy promise.

# Onboarding

Explain CreativeOtter as a shared media workspace, then help the user complete one useful action.

## What it does

- Organizes durable image, video, audio, and source assets.
- Stores brand themes with colors, fonts, logos, notes, and visual references.
- Generates and edits images across specialized models.
- Generates, transforms, and assembles video with text, image, video, audio, and Character references.
- Generates speech, designs new synthetic voices from a description, clones a consenting speaker's voice (Cartesia by default, or ElevenLabs) onto a Character or a new voice-only Character, transcribes media, and cleans recordings.
- Saves reusable Characters and multi-shot Film projects.
- Processes media with background removal, upscaling, trimming, scaling, subtitles, frames, and merging.

## First conversation

Do not generate anything or spend credits until the user chooses what to make.

1. Ask what the user wants to make or organize.
2. If they have existing media, search or import it.
3. If they need branded output, fetch or create a theme.
4. Show the recommended model and important settings for the requested modality.
5. Generate one modest example or organize one real asset before proposing a larger batch.

Before their first video, say how it starts: with Review on, a video request opens a card showing the prompt, settings and estimated credits, and rendering starts only when they press Generate; with Auto it starts when requested. Images and audio start when requested.

Use `manage_account` only when they ask about their balance, charges or settings.

## Good first tasks

- “Give my Character a voice (three designed auditions).”
- “Find and organize my existing brand assets.”
- “Create a brand theme from these files.”
- “Generate an on-brand product image.”
- “Animate this approved image into a five-second clip.”
- “Generate a narration and add it to this video.”
- “Create a Character from this reference photo.”

## Model discovery message

Do not overwhelm the user with the entire catalog. Offer one recommended model and one meaningful alternative, based on current `list_models` and `get_model_params` results.

For example:

```text
I would use Nano Banana 2 for this image. It is our general default for generation
and targeted edits, with balanced quality, speed, and cost.
If exact typography is the priority, GPT Image 2.5 Sunburst is the stronger
alternative. I can generate one candidate or compare both.
```

For video, state duration, ratio, resolution, audio behavior, and references before submission. For speech, state the voice, language, and delivery style. For a new voice without a recording, offer `design_voice` (three auditions to choose from). For voice cloning (Cartesia by default, or ElevenLabs), explain the workflow and obtain explicit consent before any mutation.

## Asset habit

After a useful result, explain that it is now a durable asset and give it a searchable name, project/brand tags, and a short description. This is the core compounding benefit of the workspace.
