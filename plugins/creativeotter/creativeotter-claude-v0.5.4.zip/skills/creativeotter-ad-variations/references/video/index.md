> CreativeOtter adaptation, 2026-11-01. [Runtime contract](../runtime-contract.md) governs execution. This inherited creative/technical guide is not a current model catalog, price list, API schema or product-policy promise.

# Video model selection

Package access does not mean loading every guide. Honor an explicit model choice. For a known model, read only its matching reference, then get_model_params for the current contract. If choosing a model, use list_models with category video first. Pricing and availability come from live tools, not these snapshots.

When the requested movement must follow an existing clip, read [motion transfer](motion-transfer.md) before selecting a model. Resolve the driving video and distinguish it from the appearance image.

| Model or family | Read when selected |
| --- | --- |
| Gemini Omni, video/gemini-omni-flash | [Gemini Omni](gemini-omni.md), the existing general default |
| Seedance 2.5 | [Seedance 2.5](seedance-2-5.md), premium cinematic, reference-rich and long (up to 30 s) scenes, 480p drafts, and supported edits/extensions |
| Kling 4.0 Omni, video/kling-4.0-omni | [Kling 4.0 Omni](kling-4.md), the recommendation for new general Kling requests: prompt templates for references, first/last frames, timed shots, dialogue and source edits; integration limits and credit estimates |
| Seedance Mini | [Seedance Mini](seedance-mini.md), only when the user asks for it |
| H3 Max, H3 Max Extend, H3 Max Insert, and H3 Max Fast/Turbo | [MiniMax H3 Max](minimax-h3-max.md), cinematic motion, cheap fast drafts, extending a clip, inserting new footage into an interval, and native audio |
| Wan 3.0 | [Wan](wan-3.md), only when explicitly requested; recommend Seedance 2.5 instead |
| Swap, replace or recast people in existing footage, including face-only swaps | `swap_video_characters`, not `generate_video`; three free previews, then Seedance 2.5 by default, or explicitly requested Wan Lite / Kling 4.0 |
| video/kling-3.0-motion-control-pro named for a swap | [Kling Motion Control Pro](kling-motion-control.md); otherwise use `swap_video_characters` |
| Copy a recorded movement or performance | [Motion transfer](motion-transfer.md), then the selected model guide; use an appearance image and driving video |
| video/minimax-h3-max-recast requested by name in generate_video | [H3 Max Recast](h3-max-recast.md); otherwise use `swap_video_characters` |
| Veo, Grok, FLUX, H3, Hailuo, HappyHorse, HeyGen or another explicitly requested route | [Additional models](other-models.md), model-specific distinctions and live-schema lookup |
| One person speaking exact lines, to camera or clearly in view, in any language | Speech first, then `video/minimax-h3-max-lip-sync` with the shot image; see [voice in video](voice-in-video.md). Several speakers or a performance-led shot keep the reference-mode paths there |
| Lip-sync a finished clip to prepared speech | [Sync 3](other-models.md), the recommended model with supplied or embedded audio and automatic or manual speaker selection; [HeyGen Lipsync](heygen-lipsync.md) when explicitly selected |
| Talking photo in an unsupported or unverified native-dialogue language | [Spoken languages](spoken-languages.md), H3 Max Lip Sync or HeyGen Avatar 4 with prepared speech |

Read [reference production](reference-production.md) when preparing shot assets, [voice in video](voice-in-video.md) when a shot has speech, and [Review/Auto](review.md) before generation. Model guides do not authorize extra paid drafts, retries or changing providers. Submit a product or quality report only when the user explicitly asks to send it; otherwise continue helping without reporting.

Planning-only requests can use this selection index without reading every model guide. Read a specific guide when committing model-specific timing, references or shot constraints. Do not render clips unless production was requested.

## Worked production recipes

Choose the relevant workflow: [product ad](recipe-product-ad.md), [consistent Character scene](recipe-character-scene.md), or [source edit and extension](recipe-source-edit.md). For creator ads, first choose a [UGC production path](ugc-paths.md).
