---
name: creativeotter-render-html
description: "Create short HTML/CSS motion-graphics videos: kinetic typography, animated shapes, transitions and logo reveals. Use for animated graphic designs, not still images or filmed footage."
---

# Create motion graphics and animations

CreativeOtter adaptation, 2026-11-06. Follow [the runtime contract](references/runtime-contract.md).

This skill is motion-only. Create animated typography, graphic sequences, moving shapes, transitions, logo reveals and short animated announcements. Output a video with meaningful visible movement, never a PNG or a still frame held for the whole video. All still-image requests—including posters, social images and static graphics—belong to creativeotter-generate-image. Filmed-looking footage belongs to video planning. Do not spend image-generation credits to create extra source artwork unless the user also requests that artwork; supplied logos and saved images may be ingredients in an animation.

The renderer uses Chromium and FFmpeg, without fal.ai. Inspect `get_capabilities.html_rendering` and the tools exposed in this chat. The backend release is opt-in; if unavailable, offer animation source or a motion plan without claiming a rendered video or spending credits. The low-level backend's PNG option does not change this skill's motion-only scope.

Build a self-contained composition with exact copy, dimensions and timing. Put visible markup in `html` and CSS keyframes in `css`; style tags, style attributes, scripts, external URLs, web fonts, audio and arbitrary HyperFrames/GSAP JavaScript are unsupported. For supplied image ingredients, pass up to four owned ready `asset_ids` and reference them as `<img src="asset:UUID">`; never publish private assets. Use even dimensions from 128 to 1920 pixels. Always set `format: "mp4"`, lasting 1–10 seconds at 12 or 24 fps. Design an entrance, visible animated progression and a readable finish, with timing independent of wall-clock time.

For a non-spending estimate, call `prepare_render` with title, format, html, css, width, height, duration_seconds, fps, asset_ids and a fresh UUID request_key. Report only the returned CreativeOtter credit amount. For an explicit animation request, continue directly with `render_design` using its returned render_id; no extra approval is needed. Reuse that ID when recovering an uncertain response. Never use an image quote or create another render to recover saving/status problems. Production prices come from the live quote; test prices are not a permanent customer policy.

Use `get_render` for progress and reopening an existing animation. Ready means succeeded, saved and charged. The CreativeOtter panel plays the MP4, refreshes private links and provides Download. Use `list_renders` to find saved work by title and select existing MP4 results for animation requests. Reopening or downloading spends no generation credits. Keep replies short and friendly, without internal IDs or technical timestamps. Do not claim a finished download from a URL alone. Confirmed failure releases reserved credits; an uncertain save remains pending for recovery.
